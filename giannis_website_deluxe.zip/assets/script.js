
// Theme (dark/light) with persistence and system preference
(function(){
  const root = document.documentElement;
  const saved = localStorage.getItem('site-theme');
  const prefersLight = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
  function applyTheme(theme){
    if(theme === 'light') document.documentElement.classList.add('light');
    else document.documentElement.classList.remove('light');
  }
  applyTheme(saved || (prefersLight ? 'light' : 'dark'));
  // toggle button
  document.addEventListener('DOMContentLoaded', ()=>{
    const btn = document.getElementById('themeToggle');
    if(btn){
      btn.addEventListener('click', ()=>{
        const isLight = document.documentElement.classList.toggle('light');
        localStorage.setItem('site-theme', isLight ? 'light' : 'dark');
      });
    }

    // mobile menu
    const hamb = document.getElementById('hamburger');
    const menu = document.getElementById('mobileMenu');
    const close = document.getElementById('mobileClose');
    hamb && hamb.addEventListener('click', ()=> menu.classList.add('open'));
    close && close.addEventListener('click', ()=> menu.classList.remove('open'));
    menu && menu.addEventListener('click', (e)=>{ if(e.target.tagName==='A') menu.classList.remove('open') });

    // smooth scroll for internal links
    document.querySelectorAll('a[href^="#"]').forEach(a=>{
      a.addEventListener('click', function(e){
        e.preventDefault();
        const t = document.querySelector(this.getAttribute('href'));
        if(t) t.scrollIntoView({behavior:'smooth', block:'start'});
      });
    });

    // scroll spy - highlight nav links
    const sections = Array.from(document.querySelectorAll('main [data-section]'));
    const navLinks = Array.from(document.querySelectorAll('nav.desktop a'));
    function onScroll(){
      const y = window.scrollY + 120;
      let current = sections[0]?.id || '';
      for(const s of sections){
        if(s.offsetTop <= y) current = s.id;
      }
      navLinks.forEach(a=> a.classList.toggle('active', a.getAttribute('href') === '#' + current));

      // back to top visibility
      const back = document.getElementById('backToTop');
      if(window.scrollY > 300) back.style.display = 'block'; else back.style.display = 'none';
    }
    window.addEventListener('scroll', onScroll);
    onScroll();

    document.getElementById('backToTop')?.addEventListener('click', ()=> window.scrollTo({top:0,behavior:'smooth'}));

    // reveal fade sections
    document.querySelectorAll('.page-fade').forEach(el=> setTimeout(()=> el.classList.add('visible'), 150));
  });
})();
