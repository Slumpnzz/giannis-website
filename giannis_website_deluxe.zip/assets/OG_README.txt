Add a 1200x630px og_image.jpg/png here to enable social previews. Filename: assets/og_image.jpg
Use a licensed image or create a custom graphic.