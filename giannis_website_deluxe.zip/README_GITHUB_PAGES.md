Deluxe Giannis Website Package
===============================

Files:
- index.html, biography.html, stats.html, awards.html, gallery.html, sources.html
- /assets/style.css, script.js, logo.svg, OG_README.txt, Giannis_Career_Timeline_Deluxe.pdf
- .github/workflows/deploy.yml (GitHub Actions for Pages deploy)

How to publish (browser method):
1. Create a new public repository on GitHub (e.g., giannis-website).
2. Upload all files and folders (drag & drop) to the repo root.
3. Commit changes.
4. Go to Settings → Pages and ensure the Pages workflow is enabled (or choose GitHub Actions workflow).
5. After the workflow runs, your site will be available at https://<username>.github.io/<repo>/

Features included:
- Dark / Light mode toggle with persistence
- Responsive hamburger menu (mobile slide-out)
- Smooth scrolling + scroll-spy for active nav highlighting
- SEO meta tags + Open Graph placeholders
- Back-to-top button & subtle page reveals
- Printable downloadable PDF timeline
- GitHub Actions workflow for automatic Pages deployment
- Sources page with authoritative links (NBA, Basketball-Reference, Reuters, Wikipedia)

Notes:
- Replace 'assets/og_image.jpg' with a licensed 1200x630 image to improve link previews.
- Replace placeholders in gallery with licensed images (put them in assets/).

Last updated: October 17, 2025
